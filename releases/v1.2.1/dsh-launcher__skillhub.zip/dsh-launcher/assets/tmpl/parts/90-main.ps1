﻿# ---------- 自动提权（2026-10-31；2026-11-01 两轮对抗审查后重写交接判据）----------
# 所有入口（桌面快捷方式 / 启动DSH-托盘.vbs / .cmd / 启动DSH.bat / 直接 -File）都走同一逻辑：
# 非管理员 → 改投「最高权限」计划任务，让 dsh web 继承管理员令牌。
# 交接判据（第二轮审查修）：不再用「有托盘进程出现」当成功——那会在托盘还没建好图标时误判，
# 也会让两个等待者互相冒充托盘。改为：
#   等待者写自己的标记 .dsh-handoff.<pid>.lock；
#   任务托盘启动时清掉所有标记，并在「图标真的可见之后」写 dsh-tray.ready；
#   等待者只有在「自己的标记消失」且「就绪信号晚于本次等待开始」时才 exit 0。
if (-not $CheckOnly) {
    $trayIsAdmin = $false
    try {
        $trayWi = [Security.Principal.WindowsIdentity]::GetCurrent()
        $trayWp = New-Object -TypeName Security.Principal.WindowsPrincipal -ArgumentList $trayWi
        $trayIsAdmin = $trayWp.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
    } catch { $trayIsAdmin = $false }
    $trayFromTask = ($env:DSH_TRAY_FROM_TASK -eq '1')
    $handoffDir = if ($PSScriptRoot) { $PSScriptRoot } else { '' }
    $myMarker = if ($handoffDir) { Join-Path $handoffDir ('.dsh-handoff.' + $PID + '.lock') } else { '' }
    $readyFile = if ($handoffDir) { Join-Path $handoffDir 'dsh-tray.ready' } else { '' }
    # 只有「被任务拉起且确实提权」的托盘才有资格签收与写就绪信号（复审严重项：否则降级会被伪装成成功）
    $handoffSigner = ($trayFromTask -and $trayIsAdmin)
    if ($handoffSigner) {
        # 清理推迟到抢到互斥锁之后：任务托盘若抢锁失败退出，等待者不会白等满 20 秒
        $script:handoffCleanupPending = $true
    }
    if ($trayFromTask -and -not $trayIsAdmin) {
        try { [void](Write-DshTrayLog -Level 'WARN' -Event 'elevation.task_not_elevated' -Fields @{ note = 'task-started tray is not elevated; running in current context to avoid a spin' }) } catch {}
    }
    if ((-not $trayIsAdmin) -and (-not $trayFromTask)) {
        $elevTaskName = 'DSH-Tray-Elevated'
        $elevTaskFound = $false
        try { $elevTaskFound = ($null -ne (Get-ScheduledTask -TaskName $elevTaskName -ErrorAction Stop)) } catch { $elevTaskFound = $false }
        if ($elevTaskFound) {
            $waiterStart = Get-Date
            if ($myMarker) {
                try { [IO.File]::WriteAllText($myMarker, ('pid=' + $PID), (New-Object System.Text.UTF8Encoding($false))) }
                catch {
                    try { [void](Write-DshTrayLog -Level 'WARN' -Event 'elevation.marker_write_failed' -Fields @{ path = [string]$myMarker; error = $_.Exception.Message }) } catch {}
                }
            }
            $runCode = -1
            try {
                # schtasks 也加超时：任务调度异常时不能把等待者永远卡在创建图标之前
                $sp = Start-Process -FilePath 'schtasks.exe' -ArgumentList @('/Run','/TN',$elevTaskName) -WindowStyle Hidden -PassThru -ErrorAction Stop
                try { $null = Wait-Process -Id $sp.Id -Timeout 20 -ErrorAction SilentlyContinue } catch {}
                $sp.Refresh()
                if (-not $sp.HasExited) {
                    # 超时或 Wait-Process 抛错：一律回收，别留残留进程
                    try { Stop-Process -Id $sp.Id -Force -ErrorAction SilentlyContinue } catch {}
                } elseif ($null -ne $sp.ExitCode) { $runCode = [int]$sp.ExitCode }
            } catch { $runCode = -1 }
            if ($runCode -eq 0) {
                $appeared = $false
                for ($k = 0; $k -lt 80; $k++) {
                    Start-Sleep -Milliseconds 250
                    if ($myMarker -and (Test-Path -LiteralPath $myMarker)) { continue }
                    if ($readyFile -and (Test-Path -LiteralPath $readyFile)) {
                        $fresh = $false
                        $alive = $false
                        try {
                            $fresh = ((Get-Item -LiteralPath $readyFile).LastWriteTime -ge $waiterStart.AddSeconds(-2))
                            $rtxt = [IO.File]::ReadAllText($readyFile)
                            $rm = [regex]::Match($rtxt, 'pid=(\d+)')
                            if ($rm.Success) { $alive = ($null -ne (Get-Process -Id ([int]$rm.Groups[1].Value) -ErrorAction SilentlyContinue)) }
                        } catch { $fresh = $false }
                        if ($fresh -and $alive) { $appeared = $true; break }
                    }
                }
                if ($appeared) {
                    if ($OpenBrowser) {
                        for ($i2 = 0; $i2 -lt 40; $i2++) {
                            if ((Get-DshListenerPid) -ne 0) { break }
                            Start-Sleep -Milliseconds 250
                        }
                        try { Open-Url $webUrl } catch {}
                    }
                    exit 0
                }
                if ($myMarker) { try { Remove-Item -LiteralPath $myMarker -Force -ErrorAction SilentlyContinue } catch {} }
                try { [void](Write-DshTrayLog -Level 'WARN' -Event 'elevation.handoff_no_tray' -Fields @{ note = 'scheduled task ran but no ready signal appeared; continuing in current context' }) } catch {}
            } else {
                if ($myMarker) { try { Remove-Item -LiteralPath $myMarker -Force -ErrorAction SilentlyContinue } catch {} }
                try { [void](Write-DshTrayLog -Level 'WARN' -Event 'elevation.handoff_failed' -Fields @{ exit = [string]$runCode }) } catch {}
            }
        }
    }
}
# ---------- 探测（CheckOnly 不抢锁、不起服务）----------
$listener = Get-DshListenerPid
if ($CheckOnly) {
    if ($listener -ne 0) { Write-Output "DSH Web 已在运行（PID $listener）" }
    else { Write-Output 'DSH Web 未运行（CheckOnly 不启动服务）' }
    Write-Output 'CheckOnly 模式结束'
    exit 0
}

# ---------- 单实例锁（2026-11-01 审查后重排：先抢锁，再动服务）----------
# 旧顺序是「先起服务、后抢锁」：两个实例同时冷启动时都判 listener=0，都往同一份
# dsh-web.log 重定向，后到者 Start-Process 抛共享冲突、在创建通知图标之前静默死掉。
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing

$mutex = New-Object System.Threading.Mutex($false, 'Local\DSH-Tray-3080')
# AbandonedMutexException 的语义是「前一个持有者死了，锁已归你」，必须当成功处理——
# 2026-11-01 第二轮审查阻断项：上一版写成 $owned=$false，导致「已有托盘时再双击」杀掉旧托盘后自己退出。
$gotLock = $false
try { $gotLock = $mutex.WaitOne(0, $false) }
catch [System.Threading.AbandonedMutexException] { $gotLock = $true }
catch { $gotLock = $false }
if (-not $gotLock) {
    # 残留托盘（僵尸图标）占着互斥锁：结束它们后接管
    Get-CimInstance Win32_Process -Filter "Name='powershell.exe' OR Name='pwsh.exe'" | Where-Object { $_.ProcessId -ne $PID -and $_.CommandLine -match '-File\s+.*DSH-tray\.ps1' } | ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    Start-Sleep -Milliseconds 800
    $mutex = New-Object System.Threading.Mutex($false, 'Local\DSH-Tray-3080')
    $owned = $false
    try { $owned = $mutex.WaitOne(0, $false) }
    catch [System.Threading.AbandonedMutexException] { $owned = $true }
    catch { $owned = $false }
    if (-not $owned) {
        # 非管理员杀不动提权托盘时走到这里：留痕，别无声退出
        try { [void](Write-DshTrayLog -Level 'WARN' -Event 'tray.mutex_busy' -Fields @{ note = 'another tray holds the mutex and could not be taken over' }) } catch {}
        if ($OpenBrowser) { try { Open-Url $webUrl } catch {} }
        exit 0
    }
}
# 锁已到手（直接成功 / Abandoned 成功 / 杀旧接管三条路径都到这里）。
if ($script:handoffCleanupPending) {
    try {
        if ($handoffDir) {
            Get-ChildItem -LiteralPath $handoffDir -Filter '.dsh-handoff.*.lock' -Force -ErrorAction SilentlyContinue |
                Remove-Item -Force -ErrorAction SilentlyContinue
        }
    } catch {}
    try { if ($readyFile) { Remove-Item -LiteralPath $readyFile -Force -ErrorAction SilentlyContinue } } catch {}
}
# 统一重探端口，抢锁前那次探测的值可能已经过期（第二轮复审意见②）。
$listener = Get-DshListenerPid

# ---------- 启动/附着服务 ----------
$proc = $null
$script:startFailed = $false
$script:startThrew = $false
$script:portBusyByOther = $false
if ($listener -eq 0) {
    try { $proc = Start-DshServer }
    catch {
        $script:startThrew = $true
        try { [void](Write-DshTrayLog -Level 'ERROR' -Event 'server.start_throw' -Fields @{ error = $_.Exception.Message }) } catch {}
        $proc = $null
    }
    if ($proc) { Write-Output "已启动 DSH Web（PID $($proc.Id)）" }
    else { Write-Output '__MODE_START_FAILED_MSG__'; $script:startFailed = $true }
} else {
    # 2026-11-01：附着前校验属主——端口被别的程序占用时绝不当作「DSH 已在运行」
    $ident = Test-DshListenerIdentity $listener
    if ($ident.Ok) {
        Write-Output "DSH Web 已在运行（PID $listener）"
    } else {
        $script:portBusyByOther = $true
        try { [void](Write-DshTrayLog -Level 'WARN' -Event 'server.port_foreign' -Fields @{ pid = [string]$listener; name = [string]$ident.Name }) } catch {}
        Write-Output ("端口 $port 被 PID $listener（" + $ident.Name + "）占用，判定不是 DSH，未启动服务")
    }
}

$notify = New-Object System.Windows.Forms.NotifyIcon
$notify.Text = "DSH Web UI  -  $webUrl"
$icoPath = Join-Path $PSScriptRoot 'whale-white.ico'
if (-not (Test-Path -LiteralPath $icoPath)) { $icoPath = Join-Path $PSScriptRoot 'whale.ico' }
if (-not (Test-Path -LiteralPath $icoPath)) { $icoPath = Join-Path $PSScriptRoot 'tray.ico' }
if (Test-Path -LiteralPath $icoPath) { $notify.Icon = New-Object System.Drawing.Icon($icoPath) } else { $notify.Icon = [System.Drawing.SystemIcons]::Application }
$notify.Visible = $true
# 就绪信号：只在「被任务拉起且已提权」时写（否则等于把非提权降级伪装成交接成功）。
if ($PSScriptRoot -and $trayFromTask -and $trayIsAdmin) {
    try { [IO.File]::WriteAllText((Join-Path $PSScriptRoot 'dsh-tray.ready'), ('pid=' + $PID + ';at=' + (Get-Date).ToString('o')), (New-Object System.Text.UTF8Encoding($false))) } catch {}
    # 写完后清一次迟到等待者的标记，避免它们空等满 20 秒
    try {
        Get-ChildItem -LiteralPath $PSScriptRoot -Filter '.dsh-handoff.*.lock' -Force -ErrorAction SilentlyContinue |
            Remove-Item -Force -ErrorAction SilentlyContinue
    } catch {}
}
__MODE_START_FAILED_BLOCK__
if ($script:portBusyByOther) {
    Show-DshNotice(9000, 'DSH', "端口 $port 被别的程序占用（PID $listener），DSH 没能启动。请关掉占用该端口的程序，或用桌面「DSH 紧急恢复」查看详情。", 'Error')
} elseif ($script:startFailed -and $script:startThrew) {
    # 抛异常≠找不到 Node：真实原因在 dsh-tray.log 的 server.start_throw
    Show-DshNotice(9000, 'DSH', '启动出错（非缺 Node）：见 dsh-tray.log，或用「DSH 紧急恢复」', 'Error')
}
# 硬重启结果回执（2026-10-26 审查 S2/S3）：上一次「硬重启托盘」里安装脚本的结果；
# 成功（setup=done 且无 notes）则静默，失败/超时/找不到脚本时用气泡如实告知
try {
    $stPath = Join-Path $PSScriptRoot 'dsh-restart-status.txt'
    if (Test-Path -LiteralPath $stPath) {
        $st = @{}
        foreach ($ln in @(Get-Content -LiteralPath $stPath -Encoding UTF8)) {
            $eq = ([string]$ln).IndexOf('=')
            if ($eq -gt 0) { $st[([string]$ln).Substring(0, $eq)] = ([string]$ln).Substring($eq + 1) }
        }
        Remove-Item -LiteralPath $stPath -Force -ErrorAction SilentlyContinue
        $stState = [string]$st['setup']
        $stNotes = [string]$st['notes']
        if (($stState -and $stState -ne 'done') -or $stNotes) {
            $stMsg = '安装脚本=' + $(if ($stState) { $stState } else { '未知' })
            $stCode = [string]$st['setupExit']
            if ($stCode -and $stCode -ne '0') { $stMsg += "（退出码 $stCode）" }
            if ($stNotes) { $stMsg += "；$stNotes" }
            Show-DshNotice(9000, 'DSH 硬重启结果', $stMsg, 'Warning')
        }
    }
} catch {}
# 外壳（Explorer）看护：Explorer 崩溃重启会丢失托盘图标注册，检测到后自动重新注册
$script:shellPid = 0
$script:shellStart = [datetime]::MinValue
try {
    $sh0 = Get-Process explorer -ErrorAction Stop | Select-Object -First 1
    if ($sh0) { $script:shellPid = $sh0.Id; $script:shellStart = $sh0.StartTime }
} catch {}
$shellTimer = New-Object System.Windows.Forms.Timer
$shellTimer.Interval = 5000
$shellTimer.Add_Tick({
    try {
        $sh = Get-Process explorer -ErrorAction Stop | Select-Object -First 1
        if ($sh -and ($sh.Id -ne $script:shellPid -or $sh.StartTime -ne $script:shellStart)) {
            $script:shellPid = $sh.Id
            $script:shellStart = $sh.StartTime
            try { $notify.Visible = $false; $notify.Visible = $true } catch {}
        }
    } catch {}
})
$shellTimer.Start()

# Web（dsh 服务）看护：服务意外停止后自动重启，无需手动（升级/崩溃后自动恢复）
# 带重启上限：连续 3 次自动重启仍未恢复 → 停止自动重启并提示（防老 DSH/坏安装反复拉起开浏览器）
$script:webDownCount = 0
$script:webRestartCount = 0
$script:webWatchdogDisabled = $false
$script:lastWebStart = [datetime]::MinValue

# ---- 自动修复（2026-09-05，多机分发）：连续自动重启仍失败时，先重跑一次 setup.ps1 ----
# （node 被升级/迁移/卸载后，托盘内写死的路径会失效；重跑 setup 会重新探测并重渲染托盘）
# 熔断标记放 %TEMP%（始终用户可写）：安装目录可能位于只读位置（如绿色软件解压到 Program Files），
# 标记写不进去会让熔断失效 → 无限自愈循环。TEMP 跨托盘重启保留，熔断语义不受影响。
$script:autoRepairMark = Join-Path $env:TEMP 'dsh-tray-autorepair.mark'
function Test-AutoRepairDue {
    # 熔断：30 分钟内只允许一次自动修复（防 node 永久缺失时无限自愈循环）
    if (-not (Test-Path -LiteralPath $script:autoRepairMark)) { return $true }
    try {
        $last = [DateTimeOffset]::FromUnixTimeSeconds([long]([System.IO.File]::ReadAllText($script:autoRepairMark)).Trim())
        return (([datetime]::UtcNow - $last.UtcDateTime).TotalMinutes -ge 30)
    } catch { return $true }
}
function Set-AutoRepairMark {
    # 返回是否写入成功：失败 = 熔断不可用 → 调用方必须 fail-closed（不自愈，直接禁用）
    try {
        [System.IO.File]::WriteAllText($script:autoRepairMark, ([DateTimeOffset]::UtcNow.ToUnixTimeSeconds().ToString()), (New-Object System.Text.UTF8Encoding($false)))
        return $true
    } catch { return $false }
}
function Start-TrayAutoRepair {
    # 独立 helper 进程接力（不能自己杀自己）：杀旧托盘 → 重跑 setup.ps1（重探测 node/DSH）→ 重启托盘
    # M2: setup 路径渲染期注入（__SETUP_PS1__），不硬编码技能目录 —— 绿色软件手动复制安装也成立
    $setupPs = '__SETUP_PS1__'
    if (-not (Test-Path -LiteralPath $setupPs)) {
        # 找不到 setup.ps1（技能被移动/改名/删除）：不白烧修复额度，直接提示人工
        Show-DshNotice(6000, 'DSH', 'DSH Web 反复启动失败，且找不到自动修复用的安装脚本（setup.ps1）。请确认技能未移动，或重新安装 dsh-launcher 后用托盘「硬重启托盘」。', 'Warning')
        return
    }
    $trayPid     = $PID
    $trayScript  = $PSCommandPath
    $helperPath  = Join-Path $env:TEMP ("dsh-autorepair-" + [guid]::NewGuid().ToString('N') + '.ps1')
    # S6(第三轮实测, 正确形态): helper 内路径以单引号字面量存（撇号 '' 翻倍，托盘展开）；
    # CLI 参数值由 helper 运行时 '"'+raw+'"' 构造（值含双引号字符→子进程 argv 剥离→兼容空格与撇号）
    $setupEsc   = $setupPs.Replace("'", "''")
    $trayEsc    = $trayScript.Replace("'", "''")
    $installEsc = $PSScriptRoot.Replace("'", "''")
    $helperEsc  = $helperPath.Replace("'", "''")
    $helper = @"
Start-Sleep -Seconds 2
Stop-Process -Id $trayPid -Force -ErrorAction SilentlyContinue
`$setupRaw = '$setupEsc'
`$setupArg = '"' + `$setupRaw + '"'
`$trayRaw = '$trayEsc'
`$trayArg = '"' + `$trayRaw + '"'
`$installRaw = '$installEsc'
`$installArg = '"' + `$installRaw + '"'
Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-File',`$setupArg,'-InstallDir',`$installArg,'-NoShortcut' -Wait -WindowStyle Hidden
Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',`$trayArg -WindowStyle Hidden
Remove-Item -LiteralPath '$helperEsc' -Force -ErrorAction SilentlyContinue
"@
    try {
        # M1: helper 必须 UTF-8 带 BOM 写入（PS 5.1 按 BOM 识别编码；无 BOM 会把含中文路径读成乱码）
        $u8 = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllBytes($helperPath, ([byte[]](0xEF,0xBB,0xBF)) + $u8.GetBytes($helper))
        Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',('"' + $helperPath + '"') -WindowStyle Hidden
    } catch { return $false }
    $notify.Visible = $false
    try { $notify.Dispose() } catch {}
    [System.Windows.Forms.Application]::Exit()
    return $true
}
$webTimer = New-Object System.Windows.Forms.Timer
$webTimer.Interval = 5000
$webTimer.Add_Tick({
    try {
        $listener = Get-DshListenerPid
        if ($listener -eq 0) {
            # 已禁用（连续失败）：仍记录，但不再自动重启/自愈（等待用户手动救活或恢复检测）
            if ($script:webWatchdogDisabled) { return }
            $script:webDownCount++
            if ($script:webDownCount -ge 3 -and ((Get-Date) - $script:lastWebStart).TotalSeconds -gt 30) {
                $script:webDownCount = 0
                $script:lastWebStart = Get-Date
                $script:webRestartCount++
                if ($script:webRestartCount -ge 3) {
                    # 自动修复优先（多机分发）：连续失败多为 node/DSH 路径失效，先重跑一次 setup.ps1 自愈
                    if (Test-AutoRepairDue) {
                        # S2(建议): setup 存在性先于写标记——缺失则提示人工 + return，不白烧 30 分钟熔断额度
                        if (-not (Test-Path -LiteralPath '__SETUP_PS1__')) {
                            $script:webWatchdogDisabled = $true
                            Show-DshNotice(6000, 'DSH', 'DSH Web 反复启动失败，且找不到自动修复用的安装脚本（setup.ps1）。请确认技能未移动，或重新安装 dsh-launcher 后用托盘「硬重启托盘」。', 'Warning')
                            return
                        }
                        # M3: 先确认熔断标记写入成功才自愈（fail-closed：TEMP 都写不了 → 不自愈循环）
                        if (-not (Set-AutoRepairMark)) {
                            $script:webWatchdogDisabled = $true
                            Show-DshNotice(6000, 'DSH', 'DSH Web 反复启动失败，且无法写入自愈标记（TEMP 不可写）。已停止自动重启。请升级 DSH，或用托盘「硬重启托盘」手动启动。', 'Warning')
                            return
                        }
                        Show-DshNotice(4000, 'DSH', 'DSH Web 反复启动失败，正在自动重跑安装脚本（重新探测 Node/DSH）并重启托盘…', 'Info')
                        $repaired = Start-TrayAutoRepair
                        # $null = 找不到 setup.ps1（函数内已弹过正确提示）；$false = 自愈进程拉不起来。两者不能混为一谈。
                        if ($null -eq $repaired) { return }
                        if (-not $repaired) {
                            $script:webWatchdogDisabled = $true
                            Show-DshNotice(6000, 'DSH', '自动修复没能拉起托盘（TEMP 不可写或无法启动进程）。已停止自动重启，请用桌面「DSH 紧急恢复」或手动启动托盘。', 'Warning')
                        }
                        return
                    }
                    $script:webWatchdogDisabled = $true
                    Show-DshNotice(6000, 'DSH', 'DSH Web 反复启动失败（自动修复后仍未恢复，可能 DSH 版本过旧或 Node.js 未安装）。已停止自动重启。请升级 DSH，或用托盘「硬重启托盘」重新探测后手动启动。', 'Warning')
                    return
                }
                Show-DshNotice(3000, 'DSH', 'DSH Web 已停止，正在自动重启…', 'Info')
                # 防挂死进程累积：重启前清理上一 proc（已自然退出则跳过）
                if ($null -ne $script:proc) {
                    try { $script:proc.Refresh() } catch {}
                    if (-not $script:proc.HasExited) { Stop-Process -Id $script:proc.Id -Force -ErrorAction SilentlyContinue }
                    $script:proc = $null
                }
                try { $script:proc = Start-DshServer }
                catch {
                    try { [void](Write-DshTrayLog -Level 'ERROR' -Event 'server.start_throw_watchdog' -Fields @{ error = $_.Exception.Message }) } catch {}
                    $script:proc = $null
                }
                if ($null -eq $script:proc) {
                    Show-DshNotice(4000, 'DSH', '__MODE_WEB_WATCHDOG_FAIL__', 'Error')
                } else {
                    # 看护重启成功：重置自动开浏览器标记；就绪 Timer 若已停止（如旧逻辑在进程退出时 Stop）则重新启动
                    $script:browserOpened = $false
                    if ($null -ne $readyTimer -and -not $readyTimer.Enabled) { $readyTimer.Start() }
                }
            }
        } else {
            if ($script:webDownCount -ge 3) {
                Show-DshNotice(2000, 'DSH', "DSH Web 已恢复（PID $listener）。", 'Info')
            }
            $script:webDownCount = 0
            $script:webRestartCount = 0
            # 服务恢复 → 重新武装看护（之前连续失败被禁用时，用户手动/升级救活后应能继续自动守护）
            if ($script:webWatchdogDisabled) {
                $script:webWatchdogDisabled = $false
                Show-DshNotice(2000, 'DSH', 'DSH Web 已恢复，看护已重新武装。', 'Info')
            }
        }
    } catch {}
})
$webTimer.Start()



# ---- CodeBuddy 网关控制（2026-10-21，托盘右键菜单）----
$script:codeBuddyGatewayDir = Join-Path $PSScriptRoot 'codebuddy-gateways'
$script:cbIntlPort = 4376
$script:cbCnPort = 54962

function Get-CodeBuddyListenerPid([int]$Port) {
    try {
        $conn = Get-NetTCPConnection -State Listen -LocalPort $Port -ErrorAction Stop | Select-Object -First 1
        if ($null -ne $conn) { return [int]$conn.OwningProcess }
    } catch {}
    return 0
}

function Get-CodeBuddyPortProcesses([int]$Port) {
    try {
        return @(Get-CimInstance Win32_Process -Filter "Name='codebuddy.exe'" -ErrorAction Stop |
            Where-Object { $_.CommandLine -match ('--serve\s+--port\s+' + $Port + '(\s|$)') })
    } catch { return @() }
}

function Update-CodeBuddyGatewayMenu {
    if ($null -eq $script:miCbIntl -or $null -eq $script:miCbCn) { return }
    foreach ($pair in @(
        @{ Item = $script:miCbIntl; Port = $script:cbIntlPort; Label = '国际' },
        @{ Item = $script:miCbCn; Port = $script:cbCnPort; Label = '国内' }
    )) {
        try {
            $listener = Get-CodeBuddyListenerPid $pair.Port
            if ($listener -gt 0) {
                $pair.Item.Text = "CodeBuddy $($pair.Label) $($pair.Port)：运行中 (PID $listener)"
            } elseif (@(Get-CodeBuddyPortProcesses $pair.Port).Count -gt 0) {
                $pair.Item.Text = "CodeBuddy $($pair.Label) $($pair.Port)：启动中…"
            } else {
                $pair.Item.Text = "CodeBuddy $($pair.Label) $($pair.Port)：已停止"
            }
        } catch {
            $pair.Item.Text = "CodeBuddy $($pair.Label) $($pair.Port)：检测失败"
        }
    }
}

function Start-CodeBuddyGateway([string]$Helper) {
    $helperPath = Join-Path $script:codeBuddyGatewayDir $Helper
    if (-not (Test-Path -LiteralPath $helperPath)) {
        try { Show-DshNotice(4000, 'CodeBuddy 网关', "找不到启动脚本：$helperPath", 'Error') } catch {}
        return
    }
    try {
        Start-Process -FilePath 'cmd.exe' -ArgumentList @('/c', $helperPath) -WindowStyle Hidden
    } catch {
        try { Show-DshNotice(4000, 'CodeBuddy 网关', "启动失败：$($_.Exception.Message)", 'Error') } catch {}
    }
}

function Restart-CodeBuddyGateway([int]$Port, [string]$Label, [string]$Helper) {
    $targets = New-Object 'System.Collections.Generic.HashSet[int]'
    $listener = Get-CodeBuddyListenerPid $Port
    if ($listener -gt 0) { [void]$targets.Add($listener) }
    foreach ($p in @(Get-CodeBuddyPortProcesses $Port)) { [void]$targets.Add([int]$p.ProcessId) }
    foreach ($procId in $targets) {
        & taskkill /PID $procId /T /F 2>$null | Out-Null
    }
    try {
        Get-CimInstance Win32_Process -Filter "Name='cmd.exe'" -ErrorAction Stop |
            Where-Object { $_.CommandLine -like "*$Helper*" } |
            ForEach-Object { Stop-Process -Id $_.ProcessId -Force -ErrorAction SilentlyContinue }
    } catch {}
    for ($i = 0; $i -lt 25; $i++) {
        if ((Get-CodeBuddyListenerPid $Port) -eq 0) { break }
        Start-Sleep -Milliseconds 200
    }
    if ((Get-CodeBuddyListenerPid $Port) -gt 0) {
        try { Show-DshNotice(4000, 'CodeBuddy 网关', "$Label 网关端口 $Port 仍被占用，未启动。", 'Error') } catch {}
        Update-CodeBuddyGatewayMenu
        return
    }
    Start-CodeBuddyGateway $Helper
    Start-Sleep -Milliseconds 700
    Update-CodeBuddyGatewayMenu
    try { Show-DshNotice(4000, 'CodeBuddy 网关', "$Label 网关正在重启（端口 $Port）。", 'Info') } catch {}
}

$menu = New-Object System.Windows.Forms.ContextMenuStrip
# 第三行需要连点 5 次：点击该行时阻止菜单自动关闭（标志位 + ItemClicked 时取消关闭），点其它项/别处照常关闭
$script:keepLauncherOpen = $false
# 用菜单级 ItemClicked 精确判断：点第三行 → 保持菜单打开（便于连点 5 次）；点其它项/别处 → 照常关闭
$menu.Add_ItemClicked({
    param($s, $e)
    if ($null -ne $e.ClickedItem -and $e.ClickedItem -eq $miLauncher) { $script:keepLauncherOpen = $true }
    else { $script:keepLauncherOpen = $false }
})
$menu.Add_Closing({
    param($s, $e)
    if ($script:keepLauncherOpen -and $e.CloseReason -eq [System.Windows.Forms.ToolStripDropDownCloseReason]::ItemClicked) {
        $e.Cancel = $true
        $script:keepLauncherOpen = $false
    }
})
# 顶部分隔线上方三行：DSH 现有版本（加粗）/ 最新版本（可更新可点）/ 启动器版本（有新版/无新版/无法检测）
$miCur = New-Object System.Windows.Forms.ToolStripMenuItem
$miCur.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9, [System.Drawing.FontStyle]::Bold)
$miCur.Text = "DSH 版本 $(Get-CurrentDshVersion)"
$menu.Items.Add($miCur) | Out-Null
$miLatest = New-Object System.Windows.Forms.ToolStripMenuItem
$miLatest.Enabled = $false
$miLatest.Text = '最新版本：查询中…'
$menu.Items.Add($miLatest) | Out-Null
$miLauncher = New-Object System.Windows.Forms.ToolStripMenuItem
$miLauncher.Font = New-Object System.Drawing.Font('Microsoft YaHei UI', 9, [System.Drawing.FontStyle]::Bold)
$miLauncher.Text = "DSH魔偶助手 $(Get-LauncherVersion)"
$menu.Items.Add($miLauncher) | Out-Null
$miGit = New-Object System.Windows.Forms.ToolStripMenuItem
$miGit.Text = '魔偶最新版本 查询中…'
$menu.Items.Add($miGit) | Out-Null
$miBranch = New-Object System.Windows.Forms.ToolStripMenuItem
$miBranch.Text = "切换同步分支：$ghBranch"
$menu.Items.Add($miBranch) | Out-Null
$miBranch.Add_Click({
    try {
        Add-Type -AssemblyName System.Windows.Forms
        Add-Type -AssemblyName System.Drawing
        $f = New-Object System.Windows.Forms.Form
        $f.Text = '切换同步分支'
        $f.StartPosition = 'CenterScreen'
        $f.FormBorderStyle = 'FixedDialog'
        $f.MaximizeBox = $false; $f.MinimizeBox = $false
        $f.ClientSize = New-Object System.Drawing.Size(380, 150)
        $lbl = New-Object System.Windows.Forms.Label
        $lbl.Text = '选择或输入 GitHub 分支（同步 dsh-launcher 源树）：'
        $lbl.SetBounds(16, 14, 348, 22)
        $cb = New-Object System.Windows.Forms.ComboBox
        $cb.DropDownStyle = [System.Windows.Forms.ComboBoxStyle]::DropDown
        $cb.SetBounds(16, 44, 348, 26)
        foreach ($b in $ghBranches) { [void]$cb.Items.Add([string]$b) }
        $cb.Text = $ghBranch
        $btnFetch = New-Object System.Windows.Forms.Button
        $btnFetch.Text = '获取已有分支'
        $btnFetch.SetBounds(16, 88, 110, 34)
        $btnOk = New-Object System.Windows.Forms.Button
        $btnOk.Text = '确定'
        $btnOk.SetBounds(132, 88, 90, 34)
        $btnCancel = New-Object System.Windows.Forms.Button
        $btnCancel.Text = '取消'
        $btnCancel.SetBounds(228, 88, 90, 34)
        $script:branchChoice = $null
        $btnFetch.Add_Click({
            try {
                $btnFetch.Enabled = $false
                $btnFetch.Text = '获取中…'
                $f.Refresh()
                # 探测 git（常见安装路径 + PATH 兜底）
                $gitExe = $null
                $cands = @('C:\Program Files\Git\cmd\git.exe', (Join-Path $env:ProgramFiles 'Git\cmd\git.exe'), (Join-Path $env:LOCALAPPDATA 'Programs\Git\cmd\git.exe'), (Join-Path $env:LOCALAPPDATA 'Programs\MinGit\cmd\git.exe'))
                $ghApp = Get-ChildItem (Join-Path $env:LOCALAPPDATA 'GitHubDesktop') -Directory -Filter 'app-*' -ErrorAction SilentlyContinue | Sort-Object Name -Descending | Select-Object -First 1
                if ($ghApp) { $cands += (Join-Path $ghApp.FullName 'resources\app\git\cmd\git.exe') }
                foreach ($c in $cands) { if ($c -and (Test-Path -LiteralPath $c)) { $gitExe = $c; break } }
                if (-not $gitExe) { $g = Get-Command git -ErrorAction SilentlyContinue; if ($g) { $gitExe = $g.Source } }
                if (-not $gitExe) { [System.Windows.Forms.MessageBox]::Show('未找到 git：无法获取分支列表。请安装 Git（https://git-scm.com）。', '切换同步分支', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null; return }
                $remoteUrl = "https://github.com/$ghRepo.git"
                # 系统代理探测，直连↔代理双路回退（与 dsh-sync 同策略）
                $sysProxy = $null
                try { $is = Get-ItemProperty -Path 'HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings' -ErrorAction Stop; if ($is.ProxyEnable -and $is.ProxyServer) { $sysProxy = [string]$is.ProxyServer } } catch {}
                $strategies = New-Object System.Collections.ArrayList
                [void]$strategies.Add(@())
                if ($sysProxy) { [void]$strategies.Add(@('-c', "http.proxy=$sysProxy", '-c', "https.proxy=$sysProxy")) }
                $out = ''; $lastCode = 1
                foreach ($st in $strategies) {
                    $cmd = @($st) + @('ls-remote', '--heads', $remoteUrl)
                    $out = (& $gitExe @cmd 2>&1 | ForEach-Object { "$_" }) -join "`n"
                    $lastCode = $LASTEXITCODE
                    if ($lastCode -eq 0) { break }
                }
                if ($lastCode -ne 0) { [System.Windows.Forms.MessageBox]::Show("获取分支失败（exit $lastCode）。请检查网络/代理后重试。`n--- 输出 ---`n$out", '切换同步分支', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null; return }
                $branches = @()
                foreach ($line in ($out -split "`n")) {
                    if ($line -match 'refs/heads/(.+)$') {
                        $b = $Matches[1].Trim()
                        if ($b -and $branches -notcontains $b) { $branches += $b }
                    }
                }
                if ($branches.Count -eq 0) { [System.Windows.Forms.MessageBox]::Show('未解析到分支（仓库为空或地址有误）。', '切换同步分支', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Warning) | Out-Null; return }
                $added = 0
                foreach ($b in ($branches | Sort-Object)) {
                    if ($cb.Items -notcontains $b) { [void]$cb.Items.Add($b); $added++ }
                }
                $lbl.Text = "已获取 $($branches.Count) 个分支（新增 $added 个），请选择或输入："
                [System.Windows.Forms.MessageBox]::Show("已获取 $($branches.Count) 个分支，新增 $added 个到下拉列表。", '切换同步分支', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Information) | Out-Null
            } catch {
                [System.Windows.Forms.MessageBox]::Show("获取分支失败：$($_.Exception.Message)", '切换同步分支', [System.Windows.Forms.MessageBoxButtons]::OK, [System.Windows.Forms.MessageBoxIcon]::Error) | Out-Null
            } finally {
                $btnFetch.Enabled = $true
                $btnFetch.Text = '获取已有分支'
            }
        })
        $btnOk.Add_Click({ $script:branchChoice = $cb.Text.Trim(); $f.Close() })
        $btnCancel.Add_Click({ $script:branchChoice = $null; $f.Close() })
        $f.Controls.Add($lbl); $f.Controls.Add($cb); $f.Controls.Add($btnFetch); $f.Controls.Add($btnOk); $f.Controls.Add($btnCancel)
        [void]$f.ShowDialog()
        $f.Dispose()
        if (-not $script:branchChoice) { return }
        $newBranch = $script:branchChoice
        if ($newBranch -eq $ghBranch) { Show-DshNotice(2000, 'DSH', "同步分支已是 $ghBranch", 'Info'); return }
        $cfgPath = Join-Path $env:USERPROFILE '.dsh\gh-sync\config.json'
        $existing = @{}
        if (Test-Path -LiteralPath $cfgPath) {
            try { $existing = Get-Content -LiteralPath $cfgPath -Raw -Encoding UTF8 | ConvertFrom-Json } catch {}
        }
        $newCfg = [ordered]@{ repo = $ghRepo; branch = $newBranch }
        if ($existing.token) { $newCfg.token = [string]$existing.token }
        elseif ($ghToken) { $newCfg.token = [string]$ghToken }
        New-Item -ItemType Directory -Force -Path (Split-Path $cfgPath) | Out-Null
        [System.IO.File]::WriteAllText($cfgPath, ($newCfg | ConvertTo-Json), (New-Object System.Text.UTF8Encoding($false)))
        Show-DshNotice(2000, 'DSH', "同步分支已切换到 $newBranch，重启托盘生效…", 'Info')
        $trayPid = $PID
        $trayScript = $PSCommandPath
        $helperPath = Join-Path $env:TEMP ("dsh-branch-" + [guid]::NewGuid().ToString('N') + '.ps1')
        # S6(第三轮实测, 正确形态): helper 内单引号字面量 + 运行时 '"'+raw+'"' 构造 CLI 参数
        $trayEsc   = $trayScript.Replace("'", "''")
        $helperEsc = $helperPath.Replace("'", "''")
        $helper = @"
Start-Sleep -Seconds 1
Stop-Process -Id $trayPid -Force -ErrorAction SilentlyContinue
`$trayRaw = '$trayEsc'
`$trayArg = '"' + `$trayRaw + '"'
Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',`$trayArg -WindowStyle Hidden
Remove-Item -LiteralPath '$helperEsc' -Force -ErrorAction SilentlyContinue
"@
        $u8b = New-Object System.Text.UTF8Encoding($false)
        [System.IO.File]::WriteAllBytes($helperPath, ([byte[]](0xEF,0xBB,0xBF)) + $u8b.GetBytes($helper))
        Start-Process -FilePath 'powershell.exe' -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',('"' + $helperPath + '"') -WindowStyle Hidden
        $notify.Visible = $false; $notify.Dispose()
        [System.Windows.Forms.Application]::Exit()
    } catch { Show-DshNotice(3000, 'DSH', "切换分支失败：$($_.Exception.Message)", 'Error') }
})
$menu.Items.Add('-') | Out-Null
$script:miCbIntl = $menu.Items.Add('CodeBuddy 国际 4376：检测中…')
$script:miCbCn = $menu.Items.Add('CodeBuddy 国内 54962：检测中…')
$script:miCbIntl.Add_Click({
    $r = [System.Windows.Forms.MessageBox]::Show("将重启 CodeBuddy 国际网关（端口 4376）。`nWeb UI 会短暂断开；国际网关启动时会等待 Clash 约 15 秒。`n`n确认继续？", 'CodeBuddy 网关', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
        try { Restart-CodeBuddyGateway -Port 4376 -Label '国际' -Helper 'start-intl.cmd' }
        catch { try { Show-DshNotice(4000, 'CodeBuddy 网关', "重启失败：$($_.Exception.Message)", 'Error') } catch {} }
    }
})
$script:miCbCn.Add_Click({
    $r = [System.Windows.Forms.MessageBox]::Show("将重启 CodeBuddy 国内网关（端口 54962）。`nWeb UI 会短暂断开。`n`n确认继续？", 'CodeBuddy 网关', [System.Windows.Forms.MessageBoxButtons]::YesNo, [System.Windows.Forms.MessageBoxIcon]::Question)
    if ($r -eq [System.Windows.Forms.DialogResult]::Yes) {
        try { Restart-CodeBuddyGateway -Port 54962 -Label '国内' -Helper 'start-cn.cmd' }
        catch { try { Show-DshNotice(4000, 'CodeBuddy 网关', "重启失败：$($_.Exception.Message)", 'Error') } catch {} }
    }
})
$menu.Add_Opening({ Update-CodeBuddyGatewayMenu })
$menu.Items.Add('-') | Out-Null
$miOpen  = $menu.Items.Add('打开 Web UI')
$miTui   = $menu.Items.Add('终端界面 (TUI)')
$miHead  = $menu.Items.Add('无界面模式 (Headless)')
$miDocs  = $menu.Items.Add('DS 开放平台')
$menu.Items.Add('-') | Out-Null
$miRestart = $menu.Items.Add('硬重启托盘')
$miExit  = $menu.Items.Add('退出并停止 DSH')
$miCur.Add_Click({ try { Open-Url 'https://deepseekdocs.com/' } catch { Show-DshNotice(3000, 'DSH', "打开文档失败：$($_.Exception.Message)", 'Error') } })
$miOpen.Add_Click({ try { Open-Url $webUrl } catch { Show-DshNotice(3000, 'DSH', "打开 Web UI 失败：$($_.Exception.Message)", 'Error') } })
$miDocs.Add_Click({ try { Open-Url 'https://platform.deepseek.com/' } catch { Show-DshNotice(3000, 'DSH', "打开开放平台失败：$($_.Exception.Message)", 'Error') } })

$miTui.Add_Click({ try { if (Test-Path -LiteralPath $launchBat) { Start-Process -FilePath $launchBat -ArgumentList '2' } else { Open-Url $webUrl } } catch { Show-DshNotice(3000, 'DSH', "打开 TUI 失败：$($_.Exception.Message)", 'Error') } })
$miHead.Add_Click({ try { if (Test-Path -LiteralPath $launchBat) { Start-Process -FilePath $launchBat -ArgumentList '3' } else { Open-Url $webUrl } } catch { Show-DshNotice(3000, 'DSH', "打开无界面模式失败：$($_.Exception.Message)", 'Error') } })
__MODE_RESTART_BODY__
$miExit.Add_Click({
    $toKill = Get-DshListenerPid
    if ($toKill -gt 0) {
        # 2026-11-01 审查：先验属主，端口被别的程序占用时绝不 taskkill
        $ident = Test-DshListenerIdentity $toKill
        if ($ident.Ok) { & taskkill /PID $toKill /T /F 2>$null | Out-Null }
        else { Show-DshNotice(6000, 'DSH', "端口 $port 被别的程序占用（PID $toKill），不是 DSH，没有结束它。", 'Warning') }
    }
    $notify.Visible = $false; $notify.Dispose()
    [System.Windows.Forms.Application]::Exit()
})
$notify.ContextMenuStrip = $menu
$script:cbAutoTimer = New-Object System.Windows.Forms.Timer
$script:cbAutoTimer.Interval = 4000
$script:cbAutoTimer.Add_Tick({
    try {
        $script:cbAutoTimer.Stop()
        foreach ($pair in @(
            @{ Port = $script:cbIntlPort; Helper = 'start-intl.cmd' },
            @{ Port = $script:cbCnPort; Helper = 'start-cn.cmd' }
        )) {
            if ((Get-CodeBuddyListenerPid $pair.Port) -eq 0 -and @(Get-CodeBuddyPortProcesses $pair.Port).Count -eq 0) {
                Start-CodeBuddyGateway $pair.Helper
            }
        }
        Update-CodeBuddyGatewayMenu
    } catch {}
})
$script:cbAutoTimer.Start()


# 启动后延迟检查更新：刷新顶部三行版本信息
$script:newerAvail = $false
$script:latestVersion = $null
$script:gitMode = $false
$script:pendingUpdate = $false
$verCheckTimer = New-Object System.Windows.Forms.Timer
$verCheckTimer.Interval = 2500
$verCheckTimer.Add_Tick({
    $verCheckTimer.Stop()
    try {
        $cur = Get-CurrentDshVersion
        $latest = Get-LatestDshInfo -TimeoutSec 8
        $miCur.Text = "DSH 版本 $cur"
        if ($latest) {
            $script:latestVersion = $latest.version
            if (Test-NewerVersion $cur $latest.version) {
                $script:newerAvail = $true
                $miLatest.Enabled = $true
                $miLatest.Text = "最新版本 $($latest.version)（点击升级）"
            } else {
                $miLatest.Enabled = $false
                $miLatest.Text = "最新版本 $($latest.version)（已是最新）"
            }
        } else {
            $miLatest.Enabled = $false
            $miLatest.Text = '最新版本：查询失败'
        }
        # 第三行：DSH魔偶助手（本地启动器版本）；第四行：魔偶最新版本 / 魔偶Git版本（同步模式）
        $ghVer = Get-GhLauncherVersion -TimeoutSec 8
        $lv = Get-LauncherVersion
        $miLauncher.Text = "DSH魔偶助手 $lv"
        if ($ghToken) {
            $script:gitMode = $true
            $miGit.Text = "魔偶Git版本 $ghVer（单击双向同步）"
        } elseif ($ghVer) {
            $script:gitMode = $false
            if (Test-NewerVersion $lv $ghVer) {
                $script:pendingUpdate = $true
                $miGit.Text = "魔偶最新版本 $ghVer（待更新）"
            } else {
                $script:pendingUpdate = $false
                $miGit.Text = "魔偶最新版本 $ghVer（无需更新）"
            }
        } else {
            $script:gitMode = $false
            $script:pendingUpdate = $false
            $miGit.Text = '魔偶最新版本 无法检测'
        }
    } catch {}
})
$verCheckTimer.Start()

# 顶部三行点击：最新版本→DSH 升级（弹窗确认后提交）；托盘版本→与 GitHub 双向同步
$miLatest.Add_Click({
    if (-not $script:newerAvail) { return }
    try {
        $instruction = Build-UpgradeInstruction (Get-CurrentDshVersion) $script:latestVersion
        Show-UpgradeDialog 'DSH 升级' $instruction
    } catch { Show-DshNotice(3000, 'DSH 升级', "准备失败：$($_.Exception.Message)", 'Error') }
})
# 第三行 5 连击 → 打开 token 配置；第四行：Git 模式（确认后双向同步）/ 待更新（更新本地）/ 无需更新（刷新 ≥1s）
$script:launchClicks = New-Object System.Collections.ArrayList
$miLauncher.Add_Click({
    try {
        $now = Get-Date
        [void]$script:launchClicks.Add($now)
        while ($script:launchClicks.Count -gt 0 -and ($now - $script:launchClicks[0]).TotalSeconds -gt 3) { $script:launchClicks.RemoveAt(0) }
        if ($script:launchClicks.Count -ge 5) {
            $script:launchClicks.Clear()
            $cfgScript = Join-Path $PSScriptRoot 'configure-git-credentials.vbs'
            if (Test-Path -LiteralPath $cfgScript) {
                Show-DshNotice(2000, 'DSH', '打开 GitHub token 配置…', 'Info')
                Start-Process wscript.exe -ArgumentList ('"' + $cfgScript + '"')
            } else {
                Show-DshNotice(3000, 'DSH', "未找到 token 配置脚本：$cfgScript", 'Error')
            }
        }
    } catch {}
})
$miGit.Add_Click({
    try {
        if ($script:gitMode) {
            # 双向同步：确认后执行（非冲突场景）
            $r = [System.Windows.Forms.MessageBox]::Show('确定执行双向同步吗？（将对比 GitHub 与本机；系统只给方向建议，绝不自动执行，方向由你选择）', 'DSH 同步', [System.Windows.Forms.MessageBoxButtons]::OKCancel, [System.Windows.Forms.MessageBoxIcon]::Question)
            if ($r -eq [System.Windows.Forms.DialogResult]::OK) {
                __MODE_SYNC_CALL__
            }
        } elseif ($script:pendingUpdate) {
            # 待更新：不再自动更新——转交同步引擎弹窗给建议，方向由用户选择
            Show-DshNotice(2000, 'DSH', '正在从 GitHub 更新启动器…', 'Info')
            $syncScript = Join-Path $PSScriptRoot 'dsh-sync.ps1'
            if (Test-Path -LiteralPath $syncScript) {
                Start-Process powershell -ArgumentList '-NoProfile','-ExecutionPolicy','Bypass','-WindowStyle','Hidden','-File',('"' + $syncScript + '"'),'-Mode','__MODE_SYNC_MODE__','-InstallDir',('"' + $PSScriptRoot + '"'),'-Direction','auto' -WindowStyle Hidden
            }
        } else {
            # 无需更新：状态刷新（查询中…，显示时间 ≥1s）
            $miGit.Text = '魔偶最新版本 查询中…'
            $miGit.Enabled = $false
            $sw = [System.Diagnostics.Stopwatch]::StartNew()
            $ghVer2 = $null
            try { $ghVer2 = Get-GhLauncherVersion -TimeoutSec 8 } catch {}
            $sw.Stop()
            $need = 1000 - $sw.ElapsedMilliseconds
            if ($need -gt 0) { Start-Sleep -Milliseconds $need }
            $lv2 = Get-LauncherVersion
            $miGit.Enabled = $true
            if ($ghVer2) {
                if (Test-NewerVersion $lv2 $ghVer2) { $script:pendingUpdate = $true; $miGit.Text = "魔偶最新版本 $ghVer2（待更新）" }
                else { $script:pendingUpdate = $false; $miGit.Text = "魔偶最新版本 $ghVer2（无需更新）" }
            } else { $miGit.Text = '魔偶最新版本 无法检测' }
        }
    } catch {}
})


# 单击无动作（不弹气泡，信息在右键菜单顶部三行显示）；双击→开 DSH 主应用（PWA 优先，回退普通浏览器）
$notify.Add_DoubleClick({ param($s, $e) try { Open-Url $webUrl } catch { Start-Process (Get-DshOpenUrl) } })

# 启动状态气泡（透明度）
# 外来端口/启动失败时已有专门的错误卡片，这里不再叠一张
if (-not $script:portBusyByOther -and -not $script:startFailed) {
    Show-DshNotice(3000, 'DSH', $(if ($listener -eq 0) { if ($null -eq $proc) { '正在启动 DSH Web...' } else { "正在启动 DSH Web（PID $($proc.Id)）..." } } else { "DSH Web 已在运行（PID $listener）" }), 'Info')
}

# 非阻塞就绪检查（Timer，不卡消息循环）
if ($OpenBrowser) {
    $script:browserOpened = $false
    $script:readyTicks = 0
    $script:noTokenHintShown = $false
$readyTimer = New-Object System.Windows.Forms.Timer
    $readyTimer.Interval = 1000
    $readyTimer.Add_Tick({
        try {
            $ok = $false
            $script:readyTicks++
            # 就绪判定两条分支口径统一（审查 S1）：端口在监听 + 日志已打印启动行 + 带认证 cookie 的 GET / 恰好 200。
            # 托盘自己拉起服务时同样走这条：只看日志文本会在令牌读不到时把 401 页当"已就绪"。
            if ($null -ne $script:proc) { $script:proc.Refresh() }
            $up = ((Get-DshListenerPid) -ne 0) -and (Test-DshReady)
            if ($up -and -not (Get-DshLaunchToken)) {
                # 服务已就绪但读不到启动令牌：不再静默降级（审查 S2），一次性告知用户怎么自救
                if (-not $script:noTokenHintShown) {
                    $script:noTokenHintShown = $true
                    try { Show-DshNotice(8000, 'DSH', "未能从 dsh-web.log 读到启动令牌：将用普通地址打开页面。若出现 401，请复制该日志里带 token 的地址在浏览器打开一次（此后 30 天内免登录）。", 'Warning') } catch {}
                }
                # 令牌读不到时无法用认证探测判定；直接判就绪并打开（提示已在上面给出），不再空等 30 秒
                $ok = $true
            } elseif ($up -and (Test-DshWebAuthed)) {
                $ok = $true
            }
            if (-not $ok -and $script:readyTicks -ge 30) {
                # 30 秒仍拿不到认证会话（读不到令牌/服务异常）：停止等待并如实提示，避免永远不开页面
                $ok = $true
                try { Show-DshNotice(8000, 'DSH', '端口已就绪但未能完成浏览器认证，将尝试直接打开页面；若看到 401，请用 dsh-web.log 里带 token 的地址打开一次。', 'Warning') } catch {}
            }
            if ($ok) { $readyTimer.Stop(); if (-not $script:browserOpened) { $script:browserOpened = $true; Show-DshNotice(2000, 'DSH', 'DSH Web 已就绪，打开浏览器。', 'Info'); try { Open-Url $webUrl } catch {} } }
        } catch {}
    })
    $readyTimer.Start()
}

try { [System.Windows.Forms.Application]::Run() } finally { $notify.Visible = $false; $notify.Dispose() }
